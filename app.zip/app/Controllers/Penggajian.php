<?php
namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\AnggotaModel;
use App\Models\KomponenModel;

class Penggajian extends BaseController
{
    protected $anggota;
    protected $komponen;
    protected $db;

    public function __construct()
    {
        $this->anggota  = new AnggotaModel();
        $this->komponen = new KomponenModel(); // $table='komponen_gaji'
        $this->db       = \Config\Database::connect();
    }

    /**
     * GET /admin/penggajian/create
     * Pilih Anggota -> tampilkan komponen valid (jabatan anggota ∪ 'Semua')
     * Tampilkan juga komponen yang sudah terdaftar (disabled).
     */
    public function create()
    {
        $idAnggota = (int) ($this->request->getGet('id_anggota') ?? 0);

        $anggotaOptions = $this->anggota
            ->select('id_anggota, gelar_depan, nama_depan, nama_belakang, gelar_belakang, jabatan, status_pernikahan, jumlah_anak')
            ->orderBy('id_anggota','ASC')
            ->findAll();

        $anggota  = null;
        $komponen = [];
        $existing = [];

        if ($idAnggota) {
            $anggota = $this->anggota->find($idAnggota);
            if ($anggota) {
                // komponen valid: jabatan sesuai atau 'Semua'
                $komponen = $this->komponen
                    ->groupStart()->where('jabatan', $anggota['jabatan'])->orWhere('jabatan','Semua')->groupEnd()
                    ->orderBy('kategori','ASC')->orderBy('nama_komponen','ASC')
                    ->findAll();

                // komponen yang sudah terdaftar untuk anggota ini
                $existing = array_column(
                    $this->db->table('penggajian')
                        ->select('id_komponen_gaji')
                        ->where('id_anggota', $idAnggota)
                        ->get()->getResultArray(),
                    'id_komponen_gaji'
                );
            }
        }

        return view('admin/penggajian/create', [
            'title'          => 'Tambah Penggajian',
            'anggotaOptions' => $anggotaOptions,
            'selectedId'     => $idAnggota,
            'anggota'        => $anggota,
            'komponen'       => $komponen,
            'existing'       => $existing, // dipakai di view untuk disable + badge "Sudah terdaftar"
        ]);
    }

    /**
     * POST /admin/penggajian/store
     * Simpan pasangan (id_anggota, id_komponen_gaji) — validasi jabatan + anti duplikat.
     */
    public function store()
    {
        $idAnggota = (int) $this->request->getPost('id_anggota');
        $selected  = $this->request->getPost('komponen') ?? []; // array id_komponen_gaji

        if (!$idAnggota || empty($selected)) {
            return redirect()->back()->withInput()->with('error','Pilih anggota dan minimal satu komponen.');
        }

        $anggota = $this->anggota->find($idAnggota);
        if (!$anggota) {
            return redirect()->back()->withInput()->with('error','Anggota tidak valid.');
        }

        // Validasi jabatan: hanya komponen {jabatan anggota} ∪ {Semua}
        $allowedIds = array_column(
            $this->komponen
                ->groupStart()->where('jabatan', $anggota['jabatan'])->orWhere('jabatan','Semua')->groupEnd()
                ->findAll(),
            'id_komponen_gaji'
        );

        $selected   = array_map('intval', array_unique($selected));
        $notAllowed = array_diff($selected, $allowedIds);
        if (!empty($notAllowed)) {
            return redirect()->back()->withInput()->with('error','Ada komponen yang tidak sesuai jabatan.');
        }

        // Ambil komponen yang sudah ada
        $existingIds = array_column(
            $this->db->table('penggajian')
                ->select('id_komponen_gaji')
                ->where('id_anggota', $idAnggota)
                ->get()->getResultArray(),
            'id_komponen_gaji'
        );

        // Bagi jadi duplikat & baru
        $dupIds = array_values(array_intersect($selected, $existingIds));
        $newIds = array_values(array_diff($selected, $existingIds));

        if (empty($newIds)) {
            // semua duplikat → tolak dengan pesan informatif
            $dupNames = !empty($dupIds)
                ? array_column($this->komponen->whereIn('id_komponen_gaji', $dupIds)->findAll(), 'nama_komponen')
                : [];
            $msg = 'Semua komponen yang dipilih sudah terdaftar' . (!empty($dupNames) ? ': '.implode(', ', $dupNames) : '') . '.';
            return redirect()->back()->withInput()->with('error', $msg);
        }

        // Insert batch (hanya yang baru)
        $rows = array_map(fn($idK) => [
            'id_anggota'       => $idAnggota,
            'id_komponen_gaji' => $idK,
        ], $newIds);

        $this->db->transStart();
        // Jika tabel punya PRIMARY KEY (id_anggota, id_komponen_gaji), ini aman.
        $this->db->table('penggajian')->insertBatch($rows);
        $this->db->transComplete();

        if (! $this->db->transStatus()) {
            $err = $this->db->error();
            return redirect()->back()->withInput()->with('error','Gagal menyimpan penggajian. '.$err['message']);
        }

        $flash = 'Berhasil menambahkan '.count($newIds).' komponen.';
        if (!empty($dupIds)) {
            $dupNames = array_column($this->komponen->whereIn('id_komponen_gaji', $dupIds)->findAll(), 'nama_komponen');
            $flash   .= ' (Diabaikan duplikat: '.implode(', ', $dupNames).')';
        }

        return redirect()->to('/admin/penggajian/create?id_anggota='.$idAnggota)
            ->with('message', $flash);
    }

    // (Index / Show / Edit / Update / Destroy akan kita isi pada commit berikutnya)
}
